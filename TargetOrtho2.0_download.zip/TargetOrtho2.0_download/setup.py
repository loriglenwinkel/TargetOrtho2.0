#unzip directories


#download genomes from wormbase parasite
