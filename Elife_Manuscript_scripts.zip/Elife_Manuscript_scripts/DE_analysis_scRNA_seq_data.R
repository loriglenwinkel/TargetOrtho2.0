library(Seurat)
library(plyr)
worm = readRDS(file ="/Users/lori/Google Drive/Hobert_Lab_ELN/analysis/targetortho_master_regulator_searchFeb2019/data/scRNAseq_Cengen2020/040920_L4_Seurat_neuron_only_SCT_normalized.rds")

#get list of neuron types from meta data
neuron_types=worm@meta.data$Cell.type
print(unique(neuron_types))

#creat new list with neuron class names 
nclasses = mapvalues(neuron_types, 
from=c("ALN","ASEL","ASER","AWC_OFF","AWC_ON","DA9","DB01","IL2_DV","IL2_LR","PDB","PLN",	"PVN",	"RIF",	"RIP",	"RIR",	"RIV",	"RMD_DV",	"RMD_LR",	"RME_DV",	"RME_LR",	"RMF",	"SAB",	"SMD",	"URA",	"URY",	"VA12",	"VB01",	"VB02",	"VC_4_5"), 
to=c("ALN",	"ASE",	"ASE",	"AWC",	"AWC",	"DA",	"DB",	"IL2",	"IL2",		"PDB",	"PLN",	"PVN",	"RIF",	"RIP",	"RIR",	"RIV",	"RMD",	"RMD",	"RME",	"RME",	"RMF",	"SAB",	"SMD",	"URA",	"URY",	"VA",	"VB",	"VB",	"VC"))
print(length(nclasses))
print(length(unique(nclasses)))

print(unique(nclasses))

#add neuron class names to meta data as new column
worm=AddMetaData(worm, nclasses, col.name = 'Neuron.class')

#take a quick look
worm@meta.data$Neuron.class

#set ident
Idents(worm) <- "Neuron.class"

nclasses=unique(worm@meta.data$Neuron.class)

for (i in nclasses){
  print(i)
  DE_genes=FindMarkers(worm, ident.1= i, test.use= 'wilcox', only.pos=TRUE,  group.by = 'Neuron.class', assay = 'SCT', logfc.threshold = 0, verbose = T) 
  print(length(DE_genes))
  head(DE_genes)
  write.csv(x = DE_genes, file =  paste("/Users/lori/Google Drive/Hobert_Lab_ELN/analysis/cengen_analysis_2019/output/DE_profiles/", i,"_vs_all_diff_wilcox_040920_data.csv"))
}



